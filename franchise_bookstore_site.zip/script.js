// script.js - простий калькулятор стартових витрат
document.addEventListener('DOMContentLoaded', function(){
  const area = document.getElementById('area');
  const rentPerM2 = document.getElementById('rentPerM2');
  const equipment = document.getElementById('equipment');
  const renovationPerM2 = document.getElementById('renovationPerM2');
  const initialStock = document.getElementById('initialStock');
  const marketing = document.getElementById('marketing');
  const licenseFee = document.getElementById('licenseFee');
  const calculateBtn = document.getElementById('calculateBtn');
  const resetBtn = document.getElementById('resetBtn');
  const result = document.getElementById('result');

  function formatUAH(n){
    return n.toLocaleString('uk-UA') + ' грн';
  }

  calculateBtn.addEventListener('click', function(){
    const a = Number(area.value) || 0;
    const rent = Number(rentPerM2.value) || 0;
    const equip = Number(equipment.value) || 0;
    const renPer = Number(renovationPerM2.value) || 0;
    const stock = Number(initialStock.value) || 0;
    const mkt = Number(marketing.value) || 0;
    const license = Number(licenseFee.value) || 0;

    // Розрахунки
    const rentMonthly = a * rent;
    const renovation = a * renPer;
    // Додаткові непередбачувані витрати — 10% від суми основного набору
    const baseSum = rentMonthly + equip + renovation + stock + mkt + license;
    const contingency = Math.round(baseSum * 0.10);

    const totalInitial = rentMonthly + equip + renovation + stock + mkt + license + contingency;

    result.innerHTML = `
      <strong>Результат розрахунку:</strong>
      <ul>
        <li>Оренда (місяць): <strong>${formatUAH(rentMonthly)}</strong></li>
        <li>Обладнання: <strong>${formatUAH(equip)}</strong></li>
        <li>Ремонт: <strong>${formatUAH(renovation)}</strong></li>
        <li>Початковий запас книг: <strong>${formatUAH(stock)}</strong></li>
        <li>Реклама та маркетинг: <strong>${formatUAH(mkt)}</strong></li>
        <li>Паушальний внесок: <strong>${formatUAH(license)}</strong></li>
        <li>Непередбачувані витрати (10%): <strong>${formatUAH(contingency)}</strong></li>
        <li style="margin-top:8px">✅ <strong>Загальна сума стартових витрат:</strong> <span style="font-size:18px">${formatUAH(totalInitial)}</span></li>
      </ul>
      <p class="note">Це попередній розрахунок для міста <strong>Київ</strong> та пакету <strong>Стандарт</strong>. Для точного бюджету зверніться до менеджера.</p>
    `;
  });

  resetBtn.addEventListener('click', function(){
    area.value = 40;
    rentPerM2.value = 12;
    equipment.value = 80000;
    renovationPerM2.value = 1500;
    initialStock.value = 100000;
    marketing.value = 30000;
    licenseFee.value = 50000;
    result.innerHTML = '';
  });

  // simple mobile menu
  const menuBtn = document.getElementById('menuBtn');
  menuBtn.addEventListener('click', function(){
    const nav = document.querySelector('.nav');
    if(nav.style.display === 'flex') nav.style.display = '';
    else nav.style.display = 'flex';
  });
});